@extends('front.layout')
@section('content')

@include('front.cabinet.include.menu')

@include('front.cabinet.view.index')

@stop
